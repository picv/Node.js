/**
 * Created by dllo on 17/2/15.
 */

var http = require('http');
var fs = require('fs');
var url = require('url');
var path = require('path');
var zhenghe = require('./zhenghe');

var server = http.createServer();

server.on('request',function (request,response) {
    if (request.url!='/favicon.ico'){
        var urlPath = url.parse(request.url).pathname;
        var filePath = path.join(__dirname,urlPath);
        // fs.stat(filePath,function (error,state) {
        //     if (!error&&state.isFile()){
        //         fs.createReadStream(filePath).pipe(response);
        //         response.statusCode=200;
        //     }else {
        //         response.statusCode =404;
        //         response.end('404 Not Found');
        //     }
        // });
        zhenghe(filePath,response);
    }else {
        response.end();
    }
});

server.listen(3001,function () {
   console.log('服务器启动成功');
});